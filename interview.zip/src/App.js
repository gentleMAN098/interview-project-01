import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Modal from './components/UI/modal';
import './index.css';
// import Info from './components/UI/userModal';

function App() {
  const [users, setUsers] = useState([]);
  const [currentPage, setCarrentPage] = useState(1);
  const [postsPerPage, setPostsPerPage] = useState(15);
  const [openModal, setOpenModal] = useState(false);
  // const [openUserModal, setOpenUserModal] = useState(false);
  const apiEndPoint = 'https://639d913d1ec9c6657bad14d3.mockapi.io/users/users';
  useEffect(() => {
    const getUsers = async () => {
      const { data: res } = await axios.get(
        apiEndPoint + '?page=' + currentPage + '&limit=' + postsPerPage
      );
      setUsers(res);
    };
    getUsers();
  }, [currentPage, postsPerPage]);

  // /////     *********** Edit user axios *************///////////   /// /
  const handleEdit = async (user) => {
    user.name = 'Edited';
    await axios.put(apiEndPoint + '/' + user.id);
    const usersClone = [...users];
    const index = usersClone.indexOf(user);
    usersClone[index] = { ...user };
    setUsers(usersClone);
    console.log(usersClone);
  };
  // /////     *********** Delete user axios *************///////////   /// /

  const handleDelete = async (user) => {
    await axios.delete(apiEndPoint + '/' + user.id);
    setUsers(users.filter((p) => p.id !== user.id));
  };
  ///////////////**********   hanlde next page pagination  ***************//////////////
  const nextPage = () => {
    setCarrentPage(currentPage + 1);
  };
  ///////////////**********   hanlde prev page pagination  ***************//////////////

  const prevPage = () => {
    setCarrentPage(currentPage - 1);
  };

  /////////// *************   loading ***********/////////////////////
  if (users.length === 0) {
    return <h2>loading...</h2>;
  }
  /////////// *************   handle select option changes ***********/////////////////////

  const handleSelectChange = (e) => {
    setPostsPerPage(e.target.value);
  };

  return (
    <div className='App'>
      <header className='App-header'>
        <p className='userCounter'>
          there are "{users.length}" users in this table
        </p>
        <button
          className='addUser'
          onClick={() => {
            setOpenModal(true);
          }}
        >
          Add a User
        </button>

        <table className='table'>
          <thead className='tableHeader'>
            <tr className='tableRow'>
              <th className='name'>Name</th>
              <th>Number</th>
              <th>Edit</th>
              <th>Delete</th>
            </tr>
          </thead>
          <tbody className='tableBody'>
            {users.map((user) => (
              <tr className='tableRow' key={user.id}>
                <td
                  className='name'
                  onClick={(e) => {
                    console.log(e);
                  }}
                >
                  {user.name}
                </td>
                <td className='name'>{user.number}</td>
                <td>
                  <button onClick={() => handleEdit(user)} className='editBtn'>
                    Edit
                  </button>
                </td>
                <td>
                  <button
                    onClick={() => {
                      handleDelete(user);
                    }}
                    className='deleteBtn'
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </header>
      <div className='footer'>
        <select onChange={handleSelectChange}>
          <option value={15}>15</option>
          <option value={20}>20</option>
          <option value={50}>50</option>
        </select>
        <button
          className='paging'
          onClick={() => {
            prevPage();
          }}
        >
          ◀ prev
        </button>
        <span className='pageCounter'>you are on page:"{currentPage}"</span>

        <button
          className='paging'
          onClick={() => {
            nextPage();
          }}
        >
          next ▶
        </button>
        <Modal
          setUsers={setUsers}
          users={users}
          open={openModal}
          onClose={() => {
            setOpenModal(false);
          }}
        />
        {/* <Info
          open={openUserModal}
          onClose={() => {
            setOpenUserModal(false);
          }}
        /> */}
      </div>
    </div>
  );
}

export default App;
