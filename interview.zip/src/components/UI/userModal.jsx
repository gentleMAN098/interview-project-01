import React from 'react';
import { useState } from 'react';
import '../../../src/index.css';
import axios from 'axios';

const Info = ({ open, onClose, setUsers, users }) => {
  const [newUserName, setNewUserName] = useState('');
  const [newUserNumber, setNewUserNumber] = useState('');
  if (!open) return null;

  const handleSubmit = async () => {
    const user = {
      name: newUserName,
      number: newUserName,
    };
    await axios.post(
      'https://639d913d1ec9c6657bad14d3.mockapi.io/users/users',
      user
    );
    setUsers([user, ...users]);
    console.log(users);
  };

  const handleNameChange = (event) => {
    setNewUserName(event.target.value);
  };
  const handleNumberChange = (event) => {
    setNewUserNumber(event.target.value);
  };

  return (
    <div onClick={onClose} className='overlay'>
      <form
        onClick={(e) => {
          e.stopPropagation();
        }}
        className='modalContainer'
        onSubmit={handleSubmit}
      >
        <div className='modalHeader'>
          <h2>Add New User {console.log(newUserName)}</h2>
          <p onClick={onClose} className='closeModal'>
            X
          </p>
        </div>

        <div className='content'>
          <label htmlFor=''>New Username:</label>
          <input
            className='userName'
            type='text'
            value={newUserName}
            name='userName'
            onChange={handleNameChange}
            placeholder='Full Name here'
          />
          <label htmlFor=''>New Number:</label>

          <input
            className='userNumber'
            type='text'
            value={newUserNumber}
            name='userNumber'
            onChange={handleNumberChange}
            placeholder='Number here'
          />
        </div>
        <div className='actions'>
          <button onClick={onClose}>Close</button>
          <input type='submit' value='submit'></input>
        </div>
      </form>
    </div>
  );
};

export default Info;
